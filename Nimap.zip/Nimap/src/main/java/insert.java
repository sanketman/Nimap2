import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class insert {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/categorytable","root","root");
		
		String str="insert into product values(?,?)";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter data");
		int a=sc.nextInt();
	    String b=sc.next();
	    
	    PreparedStatement ps=con.prepareStatement(str);
	    ps.setInt(1, a);
	    ps.setString(2, b);
	    
	    ps.execute();
	    System.out.println("record inserted successfully......");
	    con.close();  

	}

}
